        </article>
        <div class="height30"></div>
        <footer>
         <div class="copyright">&copy; thesoftwareguy All rights Reserved</div>
         <div class="footerlogo"><a href="http://www.thesoftwareguy.in" target="_blank"><img src="http://www.thesoftwareguy.in/thesoftwareguy-logo-small.png" width="200" height="47" alt="thesoftwareguy logo" /></a>
        </footer>
    </div>
</div>
</body>
</html>

